from flask import Blueprint, send_file
from app.api.utils import safe_file_access

router = Blueprint("test_route", __name__)

@router.route("/test/<path:filename>")
def test_file(filename):
    path = safe_file_access(filename)
    return send_file(path)