- [x] Create website structure (HTML)
- [x] Add content to the website
- [x] Implement styling (CSS)
- [x] Add interactivity (JavaScript)
- [x] Test website locally
- [x] Deploy website

